#include "mbed.h"
#include "USBHID.h"
 
//We declare a USBHID device. By default input and output reports are 64 bytes long.
USBHID hid(8, 8);
 
Serial pc(USBTX, USBRX);
 
//This report will contain data to be sent
HID_REPORT send_report;
HID_REPORT recv_report;
 
//DigitalOut l1(LED1);



typedef struct{
	uint8_t *cmd;
	unsigned int cmdSize;
	uint8_t *resp;
	unsigned int respSize;
}LoRaCmdPack_t;


SPI spi(D11,D12,D13);
DigitalInOut led(LED1);
DigitalInOut nss(D10);
DigitalInOut rx(D9);
DigitalInOut tx(D8);
DigitalInOut rst(D7);


DigitalInOut *gpio[] = {&nss, &rx, &tx, &rst, &led};





int process(LoRaCmdPack_t *CmdPack){
	switch(CmdPack->cmd[0]){
		case 0x11 : {//GPIO SET DIR
			if(CmdPack->cmd[2] == 1) gpio[CmdPack->cmd[1]]->output();
			else gpio[CmdPack->cmd[1]]->input();
			CmdPack->resp[0] = 1;
			CmdPack->respSize = 1;
		}
		break;
		case 0x12 : {//GPIO WRITE VALUE
			*gpio[CmdPack->cmd[1]] = CmdPack->cmd[2];
			CmdPack->resp[0] = 1;
			CmdPack->respSize = 1;
		}
		break;
		case 0x13 : {//GPIO READ VALUE
			CmdPack->resp[0] = 1;
			CmdPack->resp[1] = *gpio[CmdPack->cmd[1]];
			CmdPack->respSize = 2;
		}
		break;
	
		case 0x21 : {//SPI INIT

		}
		break;
		case 0x22 : {//SPI TRANSCIEVE BYTE
			CmdPack->resp[0] = 1;
			CmdPack->resp[1] = spi.write(CmdPack->cmd[1]);
			CmdPack->respSize = 2;
		}
		break;
		case 0x23 : {//SPI TRANSCIEVE BUFFER
			unsigned int size = CmdPack->cmd[1];
			CmdPack->resp[0] = 1;
			int i;
			for(i=0;i<size;i++){
				CmdPack->resp[1+i]= spi.write(CmdPack->cmd[2+i]);
			}

			
		}
		break;
	}
}



int main(void) {
    send_report.length = 8;
	gpio[0]->output();
	gpio[1]->output();
	gpio[2]->output();
	gpio[3]->output();
	gpio[4]->output();
    while (1) {

    //try to read a msg
    if(hid.readNB(&recv_report)) {
        //l1 = !l1;
	//*gpio[0] = !*gpio[0];
        for(int i = 0; i < recv_report.length; i++) {
            pc.printf("%#2x ", recv_report.data[i]);
        }
        pc.printf("\r\n");

	LoRaCmdPack_t CmdPack;
	CmdPack.cmd = recv_report.data;
	CmdPack.cmdSize = recv_report.length;
	CmdPack.resp = send_report.data;
	process(&CmdPack);
	send_report.length = CmdPack.respSize;
	hid.send(&send_report);


	//Fill the report
	//for (int i = 0; i < send_report.length; i++) send_report.data[i] = rand() & 0xff;

	//Send the report
	


        }
    }
}

